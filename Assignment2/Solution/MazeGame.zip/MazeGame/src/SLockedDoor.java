public class SLockedDoor extends MazeDoor {

    public SLockedDoor(String wall){
        setOpen(false);
        setWall(wall);
        setLocked(false);
        setQuestion("");
        setAnswer("UPEI");
    }

    @Override
    public void show() {}

    @Override
    public void unlock(Object obj) {
        String password;
        if(obj instanceof String){
            password = (String) obj;
        } else {
            System.out.println("Please Enter A String");
            return;
        }

        if(password.equals(getAnswer())){
            System.out.println("Door has been unlocked");
            setLocked(true);
        }
        else {
            System.out.println("Incorrect answer");
        }
    }
}
