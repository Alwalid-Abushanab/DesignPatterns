import java.util.HashMap;
import java.util.Objects;

public class BrickRoom extends MazeRoom {
    public BrickRoom(){
        doors = new HashMap<>();
    }

    @Override
    void createDoor(String wall) {
        if (!wall.equals("West") && !wall.equals("East")  && !wall.equals("North") && !wall.equals("South")){
            System.out.println("There is No wall named "+wall+ " Please use one of the following: \n1.South\n2.North\n3.East\n4.West");
            return;
        }

        MazeDoor door = new SLockedDoor(wall);

        if(!addDoor(door, wall))
        {
            System.out.println("There is a door on this wall");
        } else
            System.out.println("A Door on the "+ wall + " wall has been created");
    }

    @Override
    String description() {
        return "This is A Brick Room, it contains " + doors.size() + " Doors with password (String)";
    }
}
