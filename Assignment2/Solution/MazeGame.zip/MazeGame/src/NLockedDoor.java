public class NLockedDoor extends MazeDoor{

    public NLockedDoor(String wall){
        setOpen(false);
        setWall(wall);
        setLocked(false);
        setQuestion("");
        setAnswer("14");
    }

    @Override
    public void show() {}

    @Override
    public void unlock(Object obj) {
        int code;
        if(obj instanceof Integer){
            code = (int) obj;
        } else {
            System.out.println("Please Enter A number");
            return;
        }

        if(code == Integer.parseInt(getAnswer())){
            System.out.println("Door has been unlocked");
            setLocked(true);
        }
        else {
            System.out.println("Incorrect answer");
        }
    }
}
