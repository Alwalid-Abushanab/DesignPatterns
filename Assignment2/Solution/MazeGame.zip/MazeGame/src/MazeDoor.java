public abstract class MazeDoor {
    private boolean isOpen, locked;
    private String wall;
    private String question, answer;

    protected void setOpen(boolean bool){
        isOpen = bool;
    }

    protected void setWall(String wall)
    {
        this.wall = wall;
    }

    protected void setQuestion(String question)
    {
        this.question = question;
    }

    protected void setAnswer(String answer)
    {
        this.answer = answer;
    }

    protected String getAnswer(){
        return answer;
    }

    protected String getQuestion(){
        return question;
    }

    protected void setLocked(boolean bool)
    {
        this.locked = bool;
    }

    public void open(){
        if(!locked)
            System.out.println("the " + wall +" door is still locked");
        else if (isOpen)
            System.out.println("this " + wall + " door is open");
        else {
            System.out.println("the " + wall + " door has been opened");
            isOpen = true;
        }
    }

    public abstract void show();
    public abstract void unlock(Object obj);

}

