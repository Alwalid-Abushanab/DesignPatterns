public class NormalDoor extends MazeDoor {

    public NormalDoor(String wall){
        setOpen(false);
        setWall(wall);
        setLocked(true);
        setQuestion("");
        setAnswer("");
    }
    @Override
    public void show() {}

    @Override
    public void unlock(Object obj) {}
}
