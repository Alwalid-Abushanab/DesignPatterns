public class MazeGameDriver {
    public static void main(String[] args) {
        String west = "West";
        String east = "East";
        String south = "South";
        String north = "North";

        MazeRoom wood = new WoodenRoom();
        MazeRoom steel = new SteelRoom();
        MazeRoom brick = new BrickRoom();
        MazeRoom glass = new GlassRoom();

        //create doors on the west and north wall of the wooden room
        wood.createDoor(west);
        wood.createDoor(north);

        //create a door on the east wall of the steel room
        steel.createDoor(east);

        //create a door on the south wall of the brick room
        brick.createDoor(south);

        //create doors on all walls of the glass room
        glass.createDoor(west);
        glass.createDoor(north);
        glass.createDoor(south);
        glass.createDoor(east);

        System.out.println("_______________________________________________________");

        //get the rooms descriptions
        System.out.println(wood.description());
        System.out.println(steel.description());
        System.out.println(brick.description());
        System.out.println(glass.description());

        System.out.println("_______________________________________________________");

        //open 1 door from each room
        wood.doors.get(west).open();
        steel.doors.get(east).open();
        brick.doors.get(south).open();
        glass.doors.get(north).open();

        System.out.println("_______________________________________________________");

        //unlocking 1 door from each room
        wood.doors.get(west).unlock(2);
        steel.doors.get(east).unlock(14);
        brick.doors.get(south).unlock("UPEI");
        glass.doors.get(north).unlock("prince Edward Island");

        System.out.println("_______________________________________________________");

        //retry to open the doors
        wood.doors.get(west).open();
        steel.doors.get(east).open();
        brick.doors.get(south).open();
        glass.doors.get(north).open();

        System.out.println("_______________________________________________________");

        //show the quiz
        wood.doors.get(west).show();
        steel.doors.get(east).show();
        brick.doors.get(south).show();
        glass.doors.get(north).show();

    }
}