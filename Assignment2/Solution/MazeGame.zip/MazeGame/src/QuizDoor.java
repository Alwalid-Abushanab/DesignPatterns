public class QuizDoor extends MazeDoor {

    public QuizDoor(String wall){
        setOpen(false);
        setWall(wall);
        setLocked(false);
        setQuestion("in which province is UPEI");
        setAnswer("prince Edward Island");
    }

    @Override
    public void show() {
        System.out.println(getQuestion());
    }

    @Override
    public void unlock(Object obj) {
        String answer;

        if(obj instanceof String){
            answer = (String) obj;
        } else {
            System.out.println("Please Enter A String");
            return;
        }

        if(answer.equals(getAnswer())){
            System.out.println("Door has been unlocked");
            setLocked(true);
        }
        else {
            System.out.println("Incorrect answer");
        }
    }
}
