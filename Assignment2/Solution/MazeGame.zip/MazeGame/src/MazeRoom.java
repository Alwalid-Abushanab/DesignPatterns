import java.util.*;

public abstract class MazeRoom {
    public Map<String,MazeDoor> doors;


    abstract void createDoor(String wall);

    abstract String description();

    protected boolean addDoor(MazeDoor door, String wall)
    {
        if (doors.containsKey(wall))
            return false;
        else {
            doors.put(wall,door);
            return true;
        }
    }
}
