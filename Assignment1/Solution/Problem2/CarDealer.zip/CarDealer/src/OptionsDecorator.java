/**
 * empty abstract class that all options are going to extend
 */
public abstract class OptionsDecorator extends CarType{
}
