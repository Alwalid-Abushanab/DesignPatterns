public class NavigationOption extends OptionsDecorator {
    private int navigationCost = 1800;
    private CarType car;

    public NavigationOption(CarType car){
        //save the car
        this.car = car;
    }

    @Override
    /**
     * return the car cost with the cost of the navigation option added to it
     */
    public int Cost() {
        return navigationCost + car.Cost();
    }

    @Override
    /**
     * returns the name of the car and any options that were added
     */
    public String Description() {
        return car.Description() + ", Navigation";
    }
}
