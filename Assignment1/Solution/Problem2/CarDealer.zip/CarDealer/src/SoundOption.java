/**
 * a class for the sound option, it extends the options class
 */
public class SoundOption extends OptionsDecorator {
    private int soundCost = 1000;
    private CarType car;

    public SoundOption(CarType car){
        //save the car
        this.car = car;
    }

    @Override
    /**
     * return the car cost with the cost of the sound option added to it
     */
    public int Cost() {
        return soundCost + car.Cost();
    }

    @Override
    /**
     * returns the name of the car and any options that were added
     */
    public String Description() {
        return car.Description() + ", Sound Option";
    }
}
