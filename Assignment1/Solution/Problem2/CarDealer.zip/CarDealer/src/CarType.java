/**
 * an abstract class that defines a car.
 * a car has a type, cost, and description
 */
public abstract class CarType {
    public CarType(){}

    /**
     * a method to get the cost of the car
     * @return the cost of the car after all the options needed were added
     */
    public abstract int Cost();

    /**
     * a method to get the name of the car
     * @return the name of the car and all it's options
     */
    public abstract String Description();

}
