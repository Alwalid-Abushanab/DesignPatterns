public class Sedan extends CarType{
    private int sedanCost = 20000;

    public Sedan(){}

    @Override
    public int Cost() {
        return sedanCost;
    }

    @Override
    /**
     * returns the name of the car
     */
    public String Description() {
        return "Sedan";
    }
}
