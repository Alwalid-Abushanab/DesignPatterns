public class WheelsOption extends OptionsDecorator {
    private int wheelsCost = 2000;
    private CarType car;

    public WheelsOption(CarType car){
        //save the car
        this.car = car;
    }

    @Override
    /**
     * return the car cost with the cost of the Wheels option added to it
     */
    public int Cost() {
        return wheelsCost + car.Cost();
    }

    @Override
    /**
     * returns the name of the car and any options that were added
     */
    public String Description() {
        return car.Description() + ", Wheels Option";
    }
}
