public class SportsCar extends CarType{
    private int sportsCarCost = 30000;

    public SportsCar(){}

    @Override
    public int Cost() {
        return sportsCarCost;
    }

    @Override
    /**
     * returns the name of the car
     */
    public String Description() {
        return "Sports Car";
    }
}
