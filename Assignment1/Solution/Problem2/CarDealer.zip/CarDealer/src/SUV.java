public class SUV extends CarType{
    private int suvCost = 40000;

    public SUV(){}

    @Override
    public int Cost() {
        return suvCost;
    }

    @Override
    /**
     * returns the name of the car
     */
    public String Description() {
        return "SUV";
    }
}
