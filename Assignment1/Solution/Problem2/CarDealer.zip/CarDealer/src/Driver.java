public class Driver {
    public static void main(String[] args) {

        //test the sedan with no option
        CarType sedan = new Sedan();
        System.out.println(sedan.Description() + " Costs: " + sedan.Cost());

        //test the sedan with moonRoof
        sedan = new MoonRoofOption(sedan);
        System.out.println(sedan.Description() + " Costs: " + sedan.Cost());

        //test sports car with sound, wheels, and navigation Options
        CarType sports = new SportsCar();
        sports = new SoundOption(sports);
        sports = new WheelsOption(sports);
        sports = new NavigationOption(sports);
        System.out.println(sports.Description() + " Costs: " + sports.Cost());

        //test the SUV with wheels, and moonRoof Options
        CarType suv = new SUV();
        suv =new WheelsOption(suv);
        suv = new MoonRoofOption(suv);
        System.out.println(suv.Description() + " Costs: " + suv.Cost());

        //test the SUV with wheels, moonRoof, Sound, and Navigation Options
        suv = new SoundOption(suv);
        suv = new NavigationOption(suv);
        System.out.println(suv.Description() + " Costs: " + suv.Cost());

    }
}