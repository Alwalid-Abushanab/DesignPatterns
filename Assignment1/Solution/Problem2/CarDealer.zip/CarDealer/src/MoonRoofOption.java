public class MoonRoofOption extends OptionsDecorator {
    private int moonRoofCost = 1500;
    private CarType car;

    public MoonRoofOption(CarType car){
        //save the car
        this.car = car;
    }

    @Override
    /**
     * return the car cost with the cost of the MoonRoof option added to it
     */
    public int Cost() {
        return moonRoofCost + car.Cost();
    }

    @Override
    /**
     * returns the name of the car and any options that were added
     */
    public String Description() {
        return car.Description() + ", Moon Roof";
    }
}
