public class GameCharacterGilmour extends GameCharacter{
    public GameCharacterGilmour()
    {
        setGuitar(new GibsonLesPaulGuitar());
        setSoloAct(new SetTheGuitarOnFireSoloAct());
        setName("David Gilmour");
    }
}
