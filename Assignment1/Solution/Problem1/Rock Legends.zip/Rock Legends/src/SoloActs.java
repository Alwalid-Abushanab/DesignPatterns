/**
 * an interface for the solo acts a character can play
 */
public interface SoloActs {
    //a method to preform the solo act
    void SoloAct();
}
