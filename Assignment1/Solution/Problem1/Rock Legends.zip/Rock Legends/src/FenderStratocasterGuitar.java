public class FenderStratocasterGuitar implements Guitars{
    @Override
    /**
     * play the FenderStratocaster Guitar
     */
    public void Guitar() {
        System.out.println("Playing the Fender Stratocaster Guitar\n");
    }
}
