public class GibsonLesPaulGuitar implements Guitars{
    @Override
    /**
     * play the Gibson Les Paul Guitar
     */
    public void Guitar() {
        System.out.println("Playing the Gibson Les Paul Guitar\n");
    }
}
