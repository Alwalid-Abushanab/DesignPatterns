public class GibsonSGGuitar implements Guitars{
    @Override
    /**
     * play the Gibson SG Guitar
     */
    public void Guitar() {
        System.out.println("Playing the Gibson SG Guitar\n");
    }
}
