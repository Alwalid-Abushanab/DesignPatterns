public class JumpOffStageSoloAct implements SoloActs{
    @Override
    /**
     * preform the Jump Off Stage solo act
     */
    public void SoloAct() {
        System.out.println("Jumping Off The Stage\n");
    }
}
