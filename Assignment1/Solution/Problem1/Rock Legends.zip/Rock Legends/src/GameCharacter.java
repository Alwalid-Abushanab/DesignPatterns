/**
 * an abstract class to define a Game Character
 */
public abstract class GameCharacter {
    private Guitars guitar;
    private SoloActs soloAct;
    private String name;

    public GameCharacter() {}

    public void setGuitar(Guitars guitar)
    {
        this.guitar = guitar;
    }

    public void setSoloAct(SoloActs soloAct)
    {
        this.soloAct = soloAct;
    }

    protected void setName(String name)
    {
        this.name = name;
    }

    public void playSolo(){
        soloAct.SoloAct();
    }

    public void playGuitar(){
        guitar.Guitar();
    }

    public String getName(){
        return name;
    }
}
