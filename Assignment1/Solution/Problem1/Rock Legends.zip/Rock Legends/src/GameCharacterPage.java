public class GameCharacterPage extends GameCharacter{
    public GameCharacterPage()
    {
        setGuitar(new GibsonSGGuitar());
        setSoloAct(new SmashTheGuitarSoloAct());
        setName("Jimi Page");
    }
}
