public class SetTheGuitarOnFireSoloAct implements SoloActs{
    @Override
    /**
     * preform the set the Guitar on fire solo act
     */
    public void SoloAct() {
        System.out.println("Setting the Guitar on Fire\n");
    }
}
