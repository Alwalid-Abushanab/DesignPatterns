public class GameCharacterEdge extends GameCharacter {
    public GameCharacterEdge()
    {
        setGuitar(new FenderStratocasterGuitar());
        setSoloAct(new JumpOffStageSoloAct());
        setName("The Edge");
    }
}
