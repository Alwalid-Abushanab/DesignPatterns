/**
 * an interface for the guitars a character can play
 */
public interface Guitars {
    //a method to play a guitar
    void Guitar();
}
