public class RockLegends {
    public static void main(String[] args) {
        //create 3 different characters
        GameCharacter player1 = new GameCharacterEdge();
        GameCharacter player2 = new GameCharacterPage();
        GameCharacter player3 = new GameCharacterGilmour();

        //play their guitars
        System.out.print("\n" + player1.getName() + ": ");
        player1.playGuitar();

        System.out.print(player2.getName() + ": ");
        player2.playGuitar();

        System.out.print(player3.getName() + ": ");
        player3.playGuitar();

        //preform the solo acts
        System.out.print(player1.getName() + ": ");
        player1.playSolo();

        System.out.print(player2.getName() + ": ");
        player2.playSolo();

        System.out.print(player3.getName() + ": ");
        player3.playSolo();

        //change the first player's guitar
        player1.setGuitar(new GibsonLesPaulGuitar());
        System.out.println(player1.getName() + "Changed His Guitar to: ");
        player1.playGuitar();

        //change the 2nd player's solo act
        player2.setSoloAct(new SetTheGuitarOnFireSoloAct());
        System.out.println(player1.getName() + "Changed His solo Act to: ");
        player2.playSolo();

        //change both the solo act and guitar of the 3rd player
        player3.setGuitar(new FenderStratocasterGuitar());
        player3.setSoloAct(new JumpOffStageSoloAct());
        System.out.println(player3.getName() + "Changed His Guitar to: ");
        player3.playGuitar();
        System.out.println("And his Solo Act to: ");
        player3.playSolo();
    }
}