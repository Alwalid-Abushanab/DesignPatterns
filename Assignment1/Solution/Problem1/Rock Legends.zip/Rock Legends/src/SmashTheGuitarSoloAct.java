public class SmashTheGuitarSoloAct implements SoloActs{
    @Override
    /**
     * preform the Smash The Guitar solo act
     */
    public void SoloAct() {
        System.out.println("Smashing the Guitar\n");
    }
}
