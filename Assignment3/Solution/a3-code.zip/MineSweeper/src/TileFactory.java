public abstract class TileFactory {
    public abstract Tile createTile(int row, int col, Minesweeper minesweeper);
}