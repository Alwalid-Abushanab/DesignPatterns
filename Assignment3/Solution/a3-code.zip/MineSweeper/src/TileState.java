public interface TileState {
    void handleClick(Tile tile, int row, int col, boolean leftClick);
    void reveal(Tile tile);
    void flag(Tile tile);
    void unflag(Tile tile);
}
