import java.awt.*;

public class HiddenState implements TileState{
    @Override
    public void handleClick(Tile tile, int row, int col, boolean leftClick) {
        if (leftClick){
            if(!tile.getMinesweeper().dig(row,col)){
                tile.getMinesweeper().gameOver();
            }
        }
        else {
            flag(tile);
        }
    }

    @Override
    public void reveal(Tile tile) {
        if(tile.getValue() == 0)
        {
            tile.setText("");
        }
        else if(tile.getValue() == -1){
            tile.setText("*");
        }
        else{
            tile.setText(String.valueOf(tile.getValue()));
        }
        tile.setBackground(Color.gray);
        tile.setTileState(tile.getRevealedState());
    }

    @Override
    public void flag(Tile tile) {
        tile.setText("?");
        tile.setBackground(Color.red);
        tile.setTileState(tile.getFlaggedState());
    }

    @Override
    public void unflag(Tile tile) {
    }
}