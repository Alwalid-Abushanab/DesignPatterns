public class Main {
    public static void main(String[] args) {
        Minesweeper minesweeper = Minesweeper.getInstance(10, 1);
        Minesweeper.getInstance(5, 2);
    }
}
