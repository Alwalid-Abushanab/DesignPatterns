public class RevealedState implements TileState{
    @Override
    public void handleClick(Tile tile, int row, int col, boolean leftClick) {
    }

    @Override
    public void reveal(Tile tile) {
    }

    @Override
    public void flag(Tile tile) {
    }

    @Override
    public void unflag(Tile tile) {
    }
}
