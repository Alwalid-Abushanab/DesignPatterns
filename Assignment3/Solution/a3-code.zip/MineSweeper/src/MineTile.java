public class MineTile extends Tile {

    // Constructor
    public MineTile(int row, int col, Minesweeper minesweeper) {
        super(row, col, minesweeper);
        setValue(-1);
    }

    public boolean hasMine(){
        return true;
    }
}