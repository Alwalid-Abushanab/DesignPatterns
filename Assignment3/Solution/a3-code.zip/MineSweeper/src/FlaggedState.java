import javax.swing.*;
import java.awt.*;

public class FlaggedState implements TileState {
    @Override
    public void handleClick(Tile tile, int row, int col, boolean leftClick) {
        if(!leftClick){
            unflag(tile);
        }
    }

    @Override
    public void reveal(Tile tile) {
    }

    @Override
    public void flag(Tile tile) {
    }

    @Override
    public void unflag(Tile tile) {
        tile.setText("");
        tile.setBackground(new JButton().getBackground());
        tile.setTileState(tile.getHiddenState());
    }
}