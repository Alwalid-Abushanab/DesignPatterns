public class SafeTile extends Tile {

    // Constructor
    public SafeTile(int row, int col, Minesweeper minesweeper) {
        super(row, col, minesweeper);
    }

    @Override
    public boolean hasMine() {
        return false;
    }
}