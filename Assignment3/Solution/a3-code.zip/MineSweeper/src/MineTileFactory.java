public class MineTileFactory extends TileFactory {
    @Override
    public Tile createTile(int row, int col, Minesweeper minesweeper) {
        return new MineTile(row, col, minesweeper);
    }
}