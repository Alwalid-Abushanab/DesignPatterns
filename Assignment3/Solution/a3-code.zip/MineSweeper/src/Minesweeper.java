import java.awt.*;
import java.io.File;
import javax.swing.*;
import javax.swing.Timer;
import java.io.FileWriter;
import java.util.Scanner;


// Create the Minesweeper class
public class Minesweeper extends JFrame {

    // Instance variables
    private final Tile[][] grid;
    private final int size;
    private int dug = 0;
    private final int maxMines;
    private long startTime;
    private long endTime;
    TileFactory safeTileFactory = new SafeTileFactory();
    TileFactory mineTileFactory = new MineTileFactory();
    private static Minesweeper instance;

    // Constructor
    private Minesweeper(int size, int maxMines) {
        int currMines = 0;
        this.size = size;
        this.maxMines = maxMines;
        // Initialize variables
        grid = new Tile[size][size];

        // Set up the GUI
        setLayout(new GridLayout(size, size));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Minesweeper");
        setSize(500, 500);

        //plant the mines
        while(currMines < maxMines){
            int i = (int)(Math.random() * size);
            int j = (int)(Math.random() * size);

            grid[i][j] = mineTileFactory.createTile(i,j, this);
            currMines++;
        }

        // Add tiles to the grid
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if(grid[i][j] == null){
                    grid[i][j] = safeTileFactory.createTile(i,j, this);
                }
                add(grid[i][j]);
            }
        }

        setVisible(true);

        //assign values
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if(grid[i][j].hasMine()){
                    continue;
                }
                grid[i][j].setValue(neighbourMines(i,j));
            }
        }

        startTimer();
    }

    public static Minesweeper getInstance(int size, int maxMines) {
        if (instance == null) {
            instance = new Minesweeper(size, maxMines);
        }
        return instance;
    }

    private void startTimer(){
        startTime = System.currentTimeMillis();
        long totalTimeMillis = 0;

        try {
            // Open the file for reading
            File file = new File("src/bestTime");
            Scanner scanner = new Scanner(file);

            // Read an integer from the file
            totalTimeMillis = scanner.nextInt();

            // Close the scanner
            scanner.close();
        } catch (Exception e){
            System.out.println(e);
        }

        long totalSeconds = totalTimeMillis / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        System.out.println("The best Time so far is: " + hours + " hours " + minutes + " minutes " + seconds + " seconds");
    }

    private void stopTimer(){
        endTime = System.currentTimeMillis();

        long totalTimeMillis = endTime - startTime;
        long totalSeconds = totalTimeMillis / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        System.out.println("Total time: " + hours + " hours " + minutes + " minutes " + seconds + " seconds");
    }



    public void gameOver(){
        System.out.println("Game Over!! Good Luck next time");
        setEnabled(false);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if(grid[i][j].getTileState() == grid[i][j].getRevealedState()){
                    continue;
                }
                grid[i][j].reveal();
            }
        }

        stopTimer();

        int delay = 10000; // in milliseconds
        Timer timer = new Timer(delay, e -> dispose());
        timer.start();
    }

    private void gameWon(){
        System.out.println("Well Done!!! You won");
        setEnabled(false);
        stopTimer();

        try {
            // Open the file for reading
            File file = new File("src/bestTime");
            Scanner scanner = new Scanner(file);

            // Read an integer from the file
            long totalTimeMillis = scanner.nextInt();

            if(totalTimeMillis > endTime-startTime){
                System.out.println("A new record has been set");

                FileWriter writer = new FileWriter("src/bestTime", false);
                writer.write(Long.toString(endTime-startTime));
                writer.close();
            }

            // Close the scanner
            scanner.close();
        } catch (Exception e){
            System.out.println(e);
        }

        int delay = 10000; // in milliseconds
        Timer timer = new Timer(delay, e -> dispose());
        timer.start();
    }

    private int neighbourMines(int row, int col){
        int value = 0;

        for(int i = row-1; i <= row+1 && i < size; i++){
            for(int j = col-1; j <= col+1 && j < size; j++){
                if(i < 0 || j < 0)
                    continue;
                if(i == row && j == col){
                    continue;
                }

                if(grid[i][j].hasMine()){
                    value++;
                }
            }
        }
        return value;
    }

    public boolean dig(int row, int col){
        grid[row][col].reveal();
        if(grid[row][col].hasMine()){
            return false;
        }
        else if(grid[row][col].getValue() > 0){
            dug++;
            grid[row][col].reveal();

            if(dug == ((size*size)-maxMines)){
                gameWon();
            }
            return true;
        }

        for(int i = row-1; i <= row+1 && i < size; i++){
            for(int j = col-1; j <= col+1 && j < size; j++){
                if(i < 0 || j < 0)
                    continue;

                if(grid[i][j].isSafeToDig()){
                    if(dig(i,j)){
                        grid[i][j].reveal();
                    }
                }
            }
        }
        dug++;

        if(dug == ((size*size)-maxMines)){
            gameWon();
        }
        return true;
    }
}