import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public abstract class Tile extends JButton {

    // Instance variables
    private int value = 0;
    private final Minesweeper minesweeper;

    private final TileState hiddenState;
    private final TileState flaggedState;
    private final TileState revealedState;
    private TileState tileState;

    // Constructor
    public Tile(int row, int col, Minesweeper minesweeper) {
        this.minesweeper = minesweeper;

        hiddenState = new HiddenState();
        flaggedState = new FlaggedState();
        revealedState = new RevealedState();
        tileState = hiddenState;

        setOpaque(true);

        // Add mouse listener
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    tileState.handleClick(Tile.this, row, col, true);
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    tileState.handleClick(Tile.this, row, col, false);
                }
            }
        });
    }

    public void reveal(){
        tileState.reveal(this);
    }

    public void setValue(int value){
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public Minesweeper getMinesweeper() {
        return minesweeper;
    }

    public void setTileState(TileState state) {
        tileState = state;
    }

    public TileState getTileState() {
        return tileState;
    }

    public abstract boolean hasMine();

    public TileState getFlaggedState() {
        return flaggedState;
    }

    public TileState getHiddenState() {
        return hiddenState;
    }

    public TileState getRevealedState() {
        return revealedState;
    }

    public boolean isSafeToDig() {
        return tileState == hiddenState;
    }
}