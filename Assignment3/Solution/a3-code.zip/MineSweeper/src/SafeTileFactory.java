public class SafeTileFactory extends TileFactory {
    @Override
    public Tile createTile(int row, int col, Minesweeper minesweeper) {
        return new SafeTile(row, col, minesweeper);
    }
}